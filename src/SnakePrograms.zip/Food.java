package sample;

public class Food {
}
