package sample;

public class Score {

    private int score = 0;
    private int highScore = 0;

    public Score(){

    }

    public int getScore() {
        return score;
    }

    public int getHighScore() {
        return highScore;
    }

    public void resetScore(){
        if (score>highScore)
        {
            highScore = score;
        }
        score = 0;
    }
}
