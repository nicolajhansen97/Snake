package sample;

import java.util.ArrayList;
import java.util.List;

public class Snake {

    List<Grid> snakeList = new ArrayList<>();
    private int speed = 4;

    public Snake(int x,int y)
    {
        snakeList.add(new Grid(x/2,y/2));
        snakeList.add(new Grid(x/2,y/2));
        snakeList.add(new Grid(x/2,y/2));
    }

    public int getSpeed(){
        return speed;
    }

    public void setSpeed(int speed){
        this.speed = speed;
    }



}
