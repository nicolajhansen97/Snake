package sample;

import SnakeExample.LOL;
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.util.List;

public class Main extends Application {
    //Redo snake thing you had.

    private final int width = 20;
    private final int height = 20;
    private final int cornerSize = 25;
    private Snake snake;
    private Dir direction = Dir.Left;
    private Image img = new Image(Main.class.getResourceAsStream("ss.png"));

    public enum Dir{
        Left,Right,Up,Down
    }


    @Override
    public void start(Stage primaryStage) throws Exception {
        Pane pane = new Pane();
        Canvas c = new Canvas(width*cornerSize,height*cornerSize);
        GraphicsContext gc = c.getGraphicsContext2D();
        pane.getChildren().add(c);

        new AnimationTimer(){
            long lastTick;

            @Override
            public void handle(long now){
                if (lastTick==0){
                    lastTick = now;
                    draw(gc);
                    return;
                }
                if (now - lastTick > 1000000000 / snake.getSpeed()){
                    lastTick = now;
                    draw(gc);
                }
            }
        }.start();

        Scene scene = new Scene(pane, width*cornerSize, height*cornerSize);

        scene.addEventFilter(KeyEvent.KEY_PRESSED,key ->{
            if (key.getCode() == KeyCode.W) {
                direction = Dir.Up;
            }
            if (key.getCode() == KeyCode.S) {
                direction = Dir.Down;
            }
            if (key.getCode() == KeyCode.D) {
                direction = Dir.Right;
            }
            if (key.getCode() == KeyCode.A) {
                direction = Dir.Left;
            }
                });

        snake = new Snake(width,height);

        primaryStage.setTitle("snake test");
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    public void draw(GraphicsContext gc){

        //make snake follow
        for (int i = snake.snakeList.size()-1; i >0 ; i--) {
            snake.snakeList.get(i).cols = snake.snakeList.get(i-1).cols;
            snake.snakeList.get(i).rows = snake.snakeList.get(i-1).rows;
        }

        //make snake move
        switch (direction) {
            case Up:
                snake.snakeList.get(0).rows--;
                break;
            case Down:
                snake.snakeList.get(0).rows++;
                break;
            case Left:
                snake.snakeList.get(0).cols--;
                break;
            case Right:
                snake.snakeList.get(0).cols++;
                break;
        }

        //fill background
        gc.setFill(Color.BLACK);
        gc.fillRect(0,0,width*cornerSize,height*cornerSize);

        //draw snake
        for (Grid g: snake.snakeList) {
            //gc.setFill(Color.GREEN);
            gc.drawImage(img,g.cols*cornerSize,g.rows*cornerSize);
            //gc.fillRect(g.cols*cornerSize,g.rows*cornerSize,cornerSize-1,cornerSize-1);
        }
    }

}

