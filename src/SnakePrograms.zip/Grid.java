package sample;

public class Grid {

    private final int size = 10;
    int cols;
    int rows;


    public Grid(int cols,int rows){
        this.cols = cols;
        this.rows = rows;
    }
}
