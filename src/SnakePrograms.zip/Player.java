package sample;

public class Player {
}
